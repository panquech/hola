<?php


$conn = mysqli_connect('localhost','root','','GALERIA');
session_start();

?>