# subir_imagenes
Proyecto para subir imagenes utilizando PHP y MYSQL.
